"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bookmark,
  CalendarRange,
  FolderOpen,
  Gavel,
  Landmark,
  LayoutDashboard,
  Mail,
  Radio,
  Search,
  User,
  Users,
  Vote
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type NavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
};

const navItems: NavItem[] = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/dossiers", label: "Dossiers", icon: FolderOpen },
  { href: "/agenda", label: "Debatten", icon: CalendarRange },
  { href: "/kamerleden", label: "Kamerleden", icon: User },
  { href: "/fracties", label: "Fracties", icon: Landmark },
  { href: "/stemmingen", label: "Stemmingen", icon: Vote },
  { href: "/kamerbrieven", label: "Kamerbrieven", icon: Mail },
  { href: "/verslag", label: "Verslag", icon: Radio },
  { href: "/search", label: "Zoeken", icon: Search },
  { href: "/dashboard", label: "Mijn monitor", icon: Gavel },
  { href: "/saved", label: "Opgeslagen", icon: Bookmark },
  { href: "/account", label: "Account", icon: Users }
];

function isActivePath(pathname: string, href: string) {
  if (href === "/") {
    return pathname === "/";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

export function AppNav({ compact = false }: { compact?: boolean }) {
  const pathname = usePathname();

  return (
    <nav className={compact ? "app-nav app-nav-compact" : "app-nav"} aria-label="Hoofdnavigatie">
      {navItems.map(({ href, label, icon: Icon }) => (
        <Link className={isActivePath(pathname, href) ? "active" : undefined} href={href} key={href}>
          <Icon size={18} aria-hidden="true" />
          <span>{label}</span>
        </Link>
      ))}
    </nav>
  );
}
