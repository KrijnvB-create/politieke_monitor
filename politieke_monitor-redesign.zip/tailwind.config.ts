import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        surface: "#f7f9fb",
        "surface-bright": "#f7f9fb",
        "surface-container-lowest": "#ffffff",
        "surface-container-low": "#f2f4f6",
        "surface-container": "#eceef0",
        "surface-container-high": "#e6e8ea",
        "surface-container-highest": "#e0e3e5",
        "on-surface": "#191c1e",
        "on-surface-variant": "#45464d",
        "border-subtle": "#e2e8f0",
        primary: "#000000",
        "primary-container": "#131b2e",
        secondary: "#0060a8",
        error: "#ba1a1a",
        "paper-bg": "#f4f1e8",
        "status-adopted": "#059669",
        "status-pending": "#d97706",
        "status-rejected": "#dc2626"
      },
      borderRadius: {
        DEFAULT: "0.125rem",
        lg: "0.25rem",
        xl: "0.5rem",
        full: "0.75rem"
      },
      spacing: {
        "stack-sm": "0.25rem",
        "stack-md": "0.75rem",
        "container-max-width": "1440px",
        gutter: "1rem",
        "sidebar-width": "280px"
      },
      fontFamily: {
        "body-md": ["Inter", "ui-sans-serif", "system-ui"],
        "label-bold": ["Inter", "ui-sans-serif", "system-ui"],
        "mono-data": ["Inter", "ui-sans-serif", "system-ui"],
        "headline-lg": ["Inter", "ui-sans-serif", "system-ui"]
      },
      fontSize: {
        "body-md": ["14px", { lineHeight: "20px", fontWeight: "400" }],
        "body-sm": ["13px", { lineHeight: "18px", fontWeight: "400" }],
        "label-bold": ["12px", { lineHeight: "16px", letterSpacing: "0", fontWeight: "600" }],
        "headline-sm": ["18px", { lineHeight: "24px", fontWeight: "600" }],
        "headline-md": ["24px", { lineHeight: "32px", fontWeight: "600" }],
        "headline-lg": ["30px", { lineHeight: "36px", fontWeight: "700" }]
      }
    }
  },
  plugins: []
};

export default config;
