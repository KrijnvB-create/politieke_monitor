import Link from "next/link";
import type { ReactNode } from "react";
import {
  Activity,
  ArrowRight,
  Bookmark,
  CalendarDays,
  CheckCircle2,
  FileText,
  FolderOpen,
  Gavel,
  Mail,
  Mic,
  Search,
  UserRound,
  Vote
} from "lucide-react";
import { ApiStatusPill } from "@/components/api-status-pill";
import { getKamerkompasOverview, getMembers, getRecentDossiers, type MonitorItem } from "@/lib/tk";

type StatCardProps = {
  label: string;
  value: number | string;
  note: string;
  tone?: "blue" | "gold" | "green";
  icon: ReactNode;
};

const followedThemes = ["Stikstofbeleid", "Woningmarkt", "Digitalisering", "Buitenlandse handel"];

function itemHref(item: MonitorItem) {
  const id = encodeURIComponent(item.id);

  if (item.kind === "dossier" || item.kind === "motie") {
    return `/dossiers/${id}`;
  }

  if (item.kind === "kamerlid") {
    return `/kamerleden/${id}`;
  }

  if (item.kind === "fractie") {
    return `/fracties/${id}`;
  }

  if (item.kind === "kamerbrief") {
    return `/kamerbrieven/${id}`;
  }

  if (item.kind === "stemming") {
    return `/stemmingen/${id}`;
  }

  if (item.kind === "thema") {
    return `/search?q=${encodeURIComponent(item.title)}`;
  }

  return `/agenda/${id}`;
}

function metaText(item: MonitorItem, key: string) {
  const value = item.meta[key];

  if (typeof value === "string" || typeof value === "number") {
    return String(value);
  }

  return null;
}

async function safeItems(promise: Promise<MonitorItem[]>) {
  try {
    return await promise;
  } catch {
    return [];
  }
}

function initials(value: string) {
  return value
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("") || "TK";
}

function StatCard({ label, value, note, tone, icon }: StatCardProps) {
  return (
    <article className="kpi-card">
      <span>{label}</span>
      <div className="kpi-value">
        <strong>{value}</strong>
        <span className={tone ? `tone-${tone}` : undefined}>{note}</span>
      </div>
      <span aria-hidden="true">{icon}</span>
    </article>
  );
}

function SignalCard({ item }: { item: MonitorItem }) {
  return (
    <Link className="signal-card" href={itemHref(item)}>
      <div className="signal-meta">
        <span>{item.eyebrow}</span>
        {item.status ? <span>{item.status}</span> : null}
      </div>
      <h4>{item.title}</h4>
      {item.description ? <p>{item.description}</p> : null}
      <div className="signal-foot">
        <span>{item.date}</span>
        <ArrowRight size={16} aria-hidden="true" />
      </div>
    </Link>
  );
}

function DossierRows({ dossiers }: { dossiers: MonitorItem[] }) {
  return (
    <div className="table-shell">
      <table className="data-table">
        <thead>
          <tr>
            <th>Dossiernummer</th>
            <th>Onderwerp</th>
            <th>Status</th>
            <th>Laatste update</th>
          </tr>
        </thead>
        <tbody>
          {dossiers.length === 0 ? (
            <tr>
              <td colSpan={4}>Geen dossiers beschikbaar.</td>
            </tr>
          ) : null}
          {dossiers.slice(0, 5).map((item, index) => (
            <tr key={`${item.kind}-${item.id}`}>
              <td>{metaText(item, "Nummer") ?? item.id.slice(0, 8)}</td>
              <td>
                <Link href={itemHref(item)}>{item.title}</Link>
              </td>
              <td>
                <span className={index === 1 ? "status-badge adopted" : "status-badge"}>
                  {item.status ?? "Actief"}
                </span>
              </td>
              <td>{item.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Timeline({ items }: { items: MonitorItem[] }) {
  return (
    <div className="timeline">
      {items.slice(0, 4).map((item) => (
        <Link className="timeline-item" href={itemHref(item)} key={`${item.kind}-${item.id}`}>
          <span className="eyebrow">{item.date}</span>
          <h4>{item.title}</h4>
          <div className="timeline-meta">
            <span>{item.eyebrow}</span>
            {item.status ? <span>{item.status}</span> : null}
          </div>
        </Link>
      ))}
    </div>
  );
}

export default async function HomePage() {
  const [overview, dossiers, members] = await Promise.all([
    getKamerkompasOverview(),
    safeItems(getRecentDossiers(6)),
    safeItems(getMembers(4))
  ]);

  return (
    <main className="dashboard app-dashboard">
      <section className="dashboard-hero">
        <div>
          <p className="eyebrow">Persoonlijk dashboard</p>
          <h1>Welkom terug bij Politieke Monitor</h1>
          <p>Overzicht van de belangrijkste ontwikkelingen in de Tweede Kamer, met snelle routes naar dossiers, moties, brieven en debatten.</p>
        </div>
        <div className="dashboard-hero-actions">
          <ApiStatusPill apiOk={overview.apiOk} />
          <Link className="primary-button" href="/search">
            <Search size={18} aria-hidden="true" />
            Zoek in de Kamer
          </Link>
        </div>
      </section>

      <section className="kpi-grid" aria-label="Kerncijfers">
        <StatCard label="Nieuwe moties" value={overview.motions.length} note="recent opgehaald" tone="green" icon={<Gavel size={18} />} />
        <StatCard label="Geplande debatten" value={overview.weekAgenda.length} note="komende dagen" tone="blue" icon={<CalendarDays size={18} />} />
        <StatCard label="Open dossiers" value={dossiers.length} note="actieve signalen" tone="gold" icon={<FolderOpen size={18} />} />
        <StatCard label="Kamerbrieven" value={overview.letters.length} note="laatste updates" tone="green" icon={<Mail size={18} />} />
      </section>

      <section className="theme-strip" aria-label="Gevolgde thema's">
        <span>Gevolgde thema's</span>
        {followedThemes.map((theme, index) => (
          <Link className={index === 0 ? "theme-chip active" : "theme-chip"} href={`/search?q=${encodeURIComponent(theme)}`} key={theme}>
            {theme}
          </Link>
        ))}
        <Link className="theme-chip add" href="/search">+ Voeg toe</Link>
      </section>

      <section className="dashboard-layout">
        <div className="dashboard-main">
          <section className="dashboard-panel">
            <div className="panel-head">
              <h2 className="panel-title">
                <FolderOpen size={21} aria-hidden="true" />
                Gevolgde dossiers
              </h2>
              <Link className="panel-link" href="/dossiers">Bekijk alle</Link>
            </div>
            <DossierRows dossiers={dossiers} />
          </section>

          <div className="signal-grid">
            <section className="dashboard-panel">
              <div className="panel-head">
                <h2 className="panel-title">
                  <FileText size={21} aria-hidden="true" />
                  Nieuwe Kamerbrieven
                </h2>
                <Link className="panel-link" href="/kamerbrieven">Alle brieven</Link>
              </div>
              <div className="signal-list">
                {overview.letters.slice(0, 3).map((item) => (
                  <SignalCard item={item} key={`${item.kind}-${item.id}`} />
                ))}
              </div>
            </section>

            <section className="dashboard-panel">
              <div className="panel-head">
                <h2 className="panel-title">
                  <Gavel size={21} aria-hidden="true" />
                  Nieuwe moties
                </h2>
                <Link className="panel-link" href="/dossiers">Alle moties</Link>
              </div>
              <div className="signal-list">
                {overview.motions.slice(0, 3).map((item) => (
                  <SignalCard item={item} key={`${item.kind}-${item.id}`} />
                ))}
              </div>
            </section>
          </div>

          <section className="dashboard-panel">
            <div className="panel-head">
              <h2 className="panel-title">
                <CalendarDays size={21} aria-hidden="true" />
                Geplande debatten
              </h2>
              <Link className="panel-link" href="/agenda">Agenda openen</Link>
            </div>
            <Timeline items={overview.weekAgenda} />
          </section>
        </div>

        <aside className="dashboard-side">
          <section className="filter-panel">
            <h4>Snelmenu filter</h4>
            <div className="filter-grid">
              <Link className="filter-button" href="/stemmingen">
                <CheckCircle2 size={18} aria-hidden="true" />
                Besluiten
              </Link>
              <Link className="filter-button" href="/stemmingen">
                <Vote size={18} aria-hidden="true" />
                Stemmingen
              </Link>
              <Link className="filter-button" href="/verslag">
                <Mic size={18} aria-hidden="true" />
                Inbreng
              </Link>
              <Link className="filter-button" href="/kamerbrieven">
                <FileText size={18} aria-hidden="true" />
                Verslagen
              </Link>
            </div>
          </section>

          <section className="dashboard-panel">
            <div className="panel-head">
              <h2 className="panel-title">
                <UserRound size={21} aria-hidden="true" />
                Kamerleden in beeld
              </h2>
            </div>
            <div className="activity-list">
              {members.slice(0, 3).map((item) => (
                <Link className="activity-note" href={itemHref(item)} key={`${item.kind}-${item.id}`}>
                  <div className="activity-avatar" aria-hidden="true">{initials(item.title)}</div>
                  <div>
                    <p><strong>{item.title}</strong> staat in de actuele Kamerledenindex.</p>
                    <span>{item.description || "Tweede Kamer"}</span>
                  </div>
                </Link>
              ))}
            </div>
            <Link className="secondary-button" href="/kamerleden">
              Beheer volg-lijst
            </Link>
          </section>

          <section className="saved-note-panel">
            <h4>
              <Bookmark size={18} aria-hidden="true" />
              Opgeslagen items
            </h4>
            <div className="saved-note-list">
              <Link className="saved-note" href="/saved">
                <p>Rapport</p>
                <p>Recente Kamerstukken en opgeslagen dossiers</p>
              </Link>
              <Link className="saved-note" href="/dashboard">
                <p>Monitor</p>
                <p>Persoonlijke signalen rond gevolgde thema's</p>
              </Link>
              <Link className="saved-note" href="/verslag">
                <p>Debatverslag</p>
                <p>Laatste plenaire publicaties</p>
              </Link>
            </div>
          </section>

          <section className="filter-panel">
            <h4>Nu in de Kamer</h4>
            <div className="signal-list">
              {overview.now.slice(0, 2).map((item) => (
                <SignalCard item={item} key={`${item.kind}-${item.id}`} />
              ))}
              {overview.now.length === 0 ? (
                <div className="empty-state small">
                  <Activity size={20} aria-hidden="true" />
                  <p>Geen openbare activiteit in de live-feed.</p>
                </div>
              ) : null}
            </div>
          </section>
        </aside>
      </section>
    </main>
  );
}
