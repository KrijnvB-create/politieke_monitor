import Link from "next/link";
import { Bell, Compass, LogIn, Plus, Search, Settings } from "lucide-react";
import { AppNav } from "@/components/app-nav";
import { SignOutButton } from "@/components/sign-out-button";
import { createClient } from "@/lib/supabase/server";

type AppShellProps = {
  children: React.ReactNode;
};

function initialsFor(email?: string | null) {
  if (!email) {
    return "PM";
  }

  return email
    .split("@")[0]
    .split(/[._-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("") || "PM";
}

export async function AppShell({ children }: AppShellProps) {
  let userEmail: string | null = null;

  try {
    const supabase = await createClient();
    const { data } = await supabase.auth.getUser();
    userEmail = data.user?.email ?? null;
  } catch {
    userEmail = null;
  }

  const initials = initialsFor(userEmail);

  return (
    <div className="app-frame">
      <aside className="app-sidebar">
        <Link className="app-brand" href="/">
          <Compass size={28} aria-hidden="true" />
          <span>
            Politieke Monitor
            <small>Tweede Kamer live</small>
          </span>
        </Link>
        <AppNav />
        <div className="app-sidebar-profile">
          <div className="app-avatar" aria-hidden="true">
            {initials}
          </div>
          <div>
            <strong>{userEmail ? "Ingelogd" : "Gastprofiel"}</strong>
            <span>{userEmail ?? "Policy analyst"}</span>
          </div>
        </div>
      </aside>

      <div className="app-workspace">
        <header className="app-topbar">
          <div className="app-topbar-main">
            <Link className="app-mobile-brand" href="/">
              <Compass size={22} aria-hidden="true" />
              Politieke Monitor
            </Link>
            <h2>ParliaTrack NL</h2>
            <form className="app-search" action="/search">
              <Search size={18} aria-hidden="true" />
              <input name="q" placeholder="Zoek dossiers, Kamerleden of trefwoorden..." type="search" />
            </form>
          </div>
          <div className="app-topbar-actions">
            <Link className="icon-button" href="/dashboard" aria-label="Meldingen">
              <Bell size={18} aria-hidden="true" />
              <span className="notification-dot" />
            </Link>
            <Link className="icon-button" href="/account" aria-label="Instellingen">
              <Settings size={18} aria-hidden="true" />
            </Link>
            {userEmail ? (
              <SignOutButton />
            ) : (
              <Link className="primary-button topbar-login" href="/login">
                <LogIn size={16} aria-hidden="true" />
                Inloggen
              </Link>
            )}
          </div>
        </header>
        <div className="app-mobile-nav">
          <AppNav compact />
        </div>
        <div className="app-content">{children}</div>
      </div>

      <Link className="floating-action" href="/search" aria-label="Nieuw volgitem">
        <Plus size={28} aria-hidden="true" />
        <span>Nieuw volgitem</span>
      </Link>
    </div>
  );
}
