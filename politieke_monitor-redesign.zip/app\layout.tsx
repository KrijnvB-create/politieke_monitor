import type { Metadata } from "next";
import { AppShell } from "@/components/app-shell";
import "./globals.css";

export const metadata: Metadata = {
  title: "Politieke Monitor",
  description: "Persoonlijk dashboard voor Tweede Kamer-agenda, stemmingen, Kamerbrieven, dossiers, Kamerleden en fracties."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="nl">
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
